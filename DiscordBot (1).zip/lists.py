


rate_me_scale = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "0", "11/10", "u r perfection :)", "-88 bleck"]
bot_name = "GloBot"
bad_words = ["bitch","fuck","shit", "Globotisoldbot", "jokes are bad", "shut up", "stupid", "you little", "lmfao", "lmao", "omfg", "wtf", "idiot", "ass", "stfu", "🖕", "heck u","rape"]
laugh_words = ["lol","hah","HAH","pff","hehe", "funni"]
bot_laughs = ["lolz", "lolxd", "haha so funny...", "hehe", "stop laughing you idiot"]
sorry_words = ["rude","feels sad", "feel sad","hurt", "at you"]
thank_words = ["thx", "thank"]
crystal_ball = ["yes", "no", "maybe", "hmm, ask again", "i cannot answer that", "definitley not","absolutley yes!", "✔"]
swear_corrections =  [
  "no u",
  "No dirty langauge under my watch",
  "Ahem. LANGUAGE PLEASE.",
  "die"
]
kind_words = ["beautiful", "pretty", "kind", "caring", "addison rae", "nice", "are funny", "advanced", "artificial intelligence", "smart bot", ":D", "cute"]
bot_responses = ["wow thank you:)", "ilysm!", ":D"]
yummy_foods = ["pizza", "noodle", "pasta", "ice cream"]
emoji_foods = ["🥞", "🥗", "🍕", "🍘", "🧇", "🍩", "🍡", "🍧", "🥟", "🍝", "🥮", "🧁", "🥛🍪", "🍋", "🍲", "🍵", "🥝", "🥥",
"🌮", "STRAWBERRY ALERT🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓🍓", "🍛", "🥧", "🍹", 
"🥘", "🧆", "🍥", "🍬", "🍉", "🍭", "🍰",]

emoji_reactions = ["😀", "😂", "😅", "😪", "🤩", "😫", "🙄", 
"😏", "🤤", "😍", "😭", "😨", "😡", "🤬", "😈", "👹",
"🥵", "😐", "😑", "🤢", "😎", "😵", "😱", "😼", "😓", "😢",
"😖", "😔", "😒", "💩", "🔫", "🔪"]

opinion_agreement = ["agree", "disagree", "hm idk", "you need a therapist",  "yasss 10000%", "no♥", "faxx no printer"]                                          